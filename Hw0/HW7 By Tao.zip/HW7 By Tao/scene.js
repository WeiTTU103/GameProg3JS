
function sceneFromJSON () {
  const JSONStr = '{"obstacles":[{"center":{"x":55.48399138896358,"y":3.7419604878960863e-14,"z":-168.52291858923934},"size":20},{"center":{"x":20.34460191662488,"y":-3.112103649728026e-14,"z":140.15668837253497},"size":20},{"center":{"x":-216.27149307655193,"y":8.944439296004351e-14,"z":109.17826519476785},"size":20},{"center":{"x":85.43019926555478,"y":-6.152841486889216e-14,"z":277.09934627624},"size":20}],"targets":[{"id":0,"pos":{"x":57.98841781747916,"y":-3.2100441034729696e-14,"z":144.56753428243724}},{"id":1,"pos":{"x":-209.45749427449806,"y":1.0571679405474734e-13,"z":35.89388568823642}},{"id":2,"pos":{"x":151.777286792071,"y":5.550838596588964e-14,"z":-249.98754635191824}},{"id":3,"pos":{"x":98.88735373379829,"y":-7.287547074410552e-14,"z":328.2019428876031}}]}';
  
  let myScene = JSON.parse (JSONStr);
  
  scene.obstacles = []
  myScene.obstacles.forEach (function (obs) {
  	scene.obstacles.push (new Obstacle (new THREE.Vector3 (obs.center.x, obs.center.y, obs.center.z), 30))
  })
  
  scene.targets = []
  myScene.targets.forEach (function (tt) {
  	scene.targets.push (new Target (tt.id, new THREE.Vector3 (tt.pos.x, tt.pos.y, tt.pos.z) ))
  })

}